<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="stilo.css">
</head>
<body class = "body">
    <h1 class = "login">Login</h1>

    <form action="php.php" method="POST">
        <label for="nome">Nome:<label>
        <input type="text" name="username" id="nome">
        <label for="senha">Senha:</label>
        <input type="password" name="password" id="senha">
        <button type="submit" value="Enviar">Enviar</button>


        
</body>
</html>